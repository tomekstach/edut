=== Czater ===
Contributors: czater 
Tags: czater, live chat, czat na strone, chater
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Live chat na Twoją stronę

== Description ==

Czater.pl to darmowy live chat <https://www.czater.pl;>, który możesz w prosty i szybki sposób zainstalować na swojej stronie internetowej, dzięki czemu klienci będą mogli skontaktować się z Tobą w czasie rzeczywistym !Sprawdź sam jak dziala Czater.pl i już dziś zacznij zwiększać zaufanie swoich klientów !

== Installation ==

1.  Upload czater.pl.php to the /wp-content/plugins/ directory
2.  Activate the plugin through the 'Plugins' menu in WordPress
3.  Place yout chat code in plugion settings

==Readme Generator== 

This Readme file was generated using <a href = 'http://sudarmuthu.com/wordpress/wp-readme'>wp-readme</a>, which generates readme files for WordPress Plugins.

== Frequently asked questions ==

= A question that someone might have =

An answer to that question.

== Screenshots ==

1. 
2. 

== Changelog ==



== Upgrade notice ==



== Arbitrary section 1 ==